package com.example.tubes_angkringan.User;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tubes_angkringan.R;

public class PageCemilanPelanggan extends AppCompatActivity {

    private ImageButton Button;
    private ImageButton Keranjang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_cemilan_pelanggan);

        Button = findViewById(R.id.imageButtonbutton3);
        Keranjang = findViewById(R.id.imageButtonbutton3keranjang);


        Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // Kembali ke Page2Activity
            }
        });

        Keranjang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Pindah ke PageKeranjang
            }
        });

    }
}

