package com.example.tubes_angkringan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.ViewHolder> {

    private List<Menu> menuList;
    private Context context;
    private DataHelper dataHelper;
    private int selectedItemPosition = RecyclerView.NO_POSITION;

    public int getSelectedItemPosition() {
        return selectedItemPosition;
    }

    public void setSelectedItemPosition(int position) {
        selectedItemPosition = position;
    }

    public MenuAdapter(Context context, DataHelper dataHelper) {
        this.context = context;
        this.dataHelper = dataHelper;
        this.menuList = dataHelper.getAllMenu(); // Mendapatkan data dari database
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View menuView = inflater.inflate(R.layout.item_menu, parent, false);
        return new ViewHolder(menuView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Menu menu = menuList.get(position);

        // Tampilkan data menu di dalam ViewHolder
        holder.imageView.setImageBitmap(menu.getImageBitmap());
        holder.namaMakananTextView.setText(menu.getNamaMakanan());
        holder.keteranganMakananTextView.setText(menu.getKeteranganMakanan());
        holder.hargaMakananTextView.setText(String.format("Rp %.2f", menu.getHargaMakanan()));

        // Mengatur warna latar belakang item yang dipilih
        if (position == selectedItemPosition) {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.transparent_black));
        } else {
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent));
        }

    }

    @Override
    public int getItemCount() {
        return menuList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView imageView;
        TextView namaMakananTextView;
        TextView keteranganMakananTextView;
        TextView hargaMakananTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // Tambahkan onClickListener pada itemView
            itemView.setOnClickListener(this);

            // Inisialisasi elemen-elemen di dalam ViewHolder
            imageView = itemView.findViewById(R.id.imageViewMenu);
            namaMakananTextView = itemView.findViewById(R.id.namaMakananTextView);
            keteranganMakananTextView = itemView.findViewById(R.id.keteranganMakananTextView);
            hargaMakananTextView = itemView.findViewById(R.id.hargaMakananTextView);
        }

        @Override
        public void onClick(View v) {
            // Mengatur posisi item yang dipilih saat item diklik
            setSelectedItemPosition(getAdapterPosition());
            notifyDataSetChanged(); // Memperbarui tampilan RecyclerView
        }
    }

    public MenuAdapter(List<Menu> menuList) {
        this.menuList = menuList;
        notifyDataSetChanged();
    }

    public void updateData() {
        this.menuList = dataHelper.getAllMenu(); // Mendapatkan data terbaru dari database
        notifyDataSetChanged(); // Memperbarui tampilan RecyclerView
    }
}
