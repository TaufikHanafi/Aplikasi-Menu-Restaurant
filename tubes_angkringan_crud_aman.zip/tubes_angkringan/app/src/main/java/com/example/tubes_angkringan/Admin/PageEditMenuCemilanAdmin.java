package com.example.tubes_angkringan.Admin;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tubes_angkringan.R;

public class PageEditMenuCemilanAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_edit_menu_cemilan);
    }
}
