package com.example.tubes_angkringan.Admin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tubes_angkringan.DataHelper;
import com.example.tubes_angkringan.Menu;
import com.example.tubes_angkringan.MenuAdapter;
import com.example.tubes_angkringan.R;

import java.util.List;

public class PageDeleteMakananAdmin extends AppCompatActivity {

    // Deklarasikan menuList dan menuAdapter
    private List<Menu> menuList;
    private MenuAdapter menuAdapter;
    private DataHelper dataHelper;

    private TextView textViewDeleteTitle;
    private TextView textViewDeleteConfirmation;
    private Button buttonDelete;
    private Button buttonCancel;

    private Menu menuToDelete;
    private int deletedMenuPosition;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_delete_makanan_admin);

        dataHelper = new DataHelper(this);

        textViewDeleteTitle = findViewById(R.id.textViewDeleteTitle);
        textViewDeleteConfirmation = findViewById(R.id.textViewDeleteConfirmation);
        buttonDelete = findViewById(R.id.buttonDelete);
        buttonCancel = findViewById(R.id.buttonCancel);

        // Terima objek Menu dan posisi dari intent
        Intent intent = getIntent();
        if (intent.hasExtra("menu") && intent.hasExtra("position")) {
            menuToDelete = intent.getParcelableExtra("menu");
            deletedMenuPosition = intent.getIntExtra("position", -1);
        }

        // Set teks sesuai dengan menu yang akan dihapus
        if (menuToDelete != null) {
            String menuName = menuToDelete.getNamaMakanan();
            textViewDeleteTitle.setText("Delete " + menuName);
            textViewDeleteConfirmation.setText("Are you sure you want to delete " + menuName + "?");
        }

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (menuToDelete != null) {
                    // Hapus menu dari database
                    int result = dataHelper.deleteMenu(menuToDelete.getId());

                    if (result > 0) {
                        // Hapus menu dari daftar (contoh: menuList)
                        menuList.remove(deletedMenuPosition);

                        // Kirim hasil ke ListMenuMakanAdmin
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("deletedMenu", menuToDelete);
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    } else {
                        // Gagal menghapus menu di database
                        // Tambahkan penanganan kesalahan sesuai kebutuhan
                    }
                } else {
                    // Menu yang akan dihapus tidak valid, berikan hasil batal
                    setResult(RESULT_CANCELED);
                    finish();
                }
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Batal menghapus, kembali ke ListMenuMakanAdmin tanpa melakukan apa pun
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }
}
