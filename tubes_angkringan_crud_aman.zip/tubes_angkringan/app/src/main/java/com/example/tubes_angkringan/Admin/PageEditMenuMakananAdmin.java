package com.example.tubes_angkringan.Admin;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.tubes_angkringan.DataHelper;
import com.example.tubes_angkringan.Menu;
import com.example.tubes_angkringan.R;

public class PageEditMenuMakananAdmin extends AppCompatActivity {

    private EditText etNamaMakanan;
    private EditText etKeteranganMakanan;
    private EditText etHargaMakanan;
    private ImageButton updateButton;
    private ImageButton backButton;

    private Menu menu;
    private int position;
    private DataHelper dataHelper;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_edit_menu_makanan);

        dataHelper = new DataHelper(this);

        etNamaMakanan = findViewById(R.id.editNamaMakanan);
        etKeteranganMakanan = findViewById(R.id.editKeteranganMakanan);
        etHargaMakanan = findViewById(R.id.editHargaMakanan);
        updateButton = findViewById(R.id.imageButton21);
        backButton = findViewById(R.id.imageButton17);

        // Menerima objek Menu dan posisi dari intent
        Intent intent = getIntent();
        if (intent.hasExtra("menu") && intent.hasExtra("position")) {
            menu = intent.getParcelableExtra("menu");
            position = intent.getIntExtra("position", -1);
            displayMenuDetails();
        }

        // Mengatur tindakan klik tombol Update
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateMenu();
            }
        });

        // Mengatur tindakan klik tombol Kembali
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // Menampilkan detail menu pada halaman edit
    private void displayMenuDetails() {
        etNamaMakanan.setText(menu.getNamaMakanan());
        etKeteranganMakanan.setText(menu.getKeteranganMakanan());
        etHargaMakanan.setText(String.valueOf(menu.getHargaMakanan()));
    }

    // Melakukan pembaruan pada objek Menu
    private void updateMenu() {
        if (menu != null) {
            menu.setNamaMakanan(etNamaMakanan.getText().toString());
            menu.setKeteranganMakanan(etKeteranganMakanan.getText().toString());
            try {
                double hargaMakanan = Double.parseDouble(etHargaMakanan.getText().toString());
                menu.setHargaMakanan(hargaMakanan);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }

            // Melakukan pembaruan pada database
            int result = dataHelper.updateMenu(menu);

            if (result > 0) {
                // Mengirim objek Menu yang diperbarui kembali ke ListMenuMakanAdmin
                Intent resultIntent = new Intent();
                resultIntent.putExtra("updatedMenu", menu);
                resultIntent.putExtra("position", position);
                setResult(RESULT_OK, resultIntent);

                // Menutup halaman edit setelah pembaruan
                finish();
            } else {
                // Gagal memperbarui menu di database
                // Tambahkan penanganan kesalahan sesuai kebutuhan
            }
        }
    }
}
