package com.example.tubes_angkringan.Admin;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tubes_angkringan.DataHelper;
import com.example.tubes_angkringan.MenuAdapter;
import com.example.tubes_angkringan.Menu;
import com.example.tubes_angkringan.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ListMenuMakanAdmin extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MenuAdapter menuAdapter;
    private List<Menu> menuList;
    private ImageButton tambah;
    private ImageButton update;
    private ImageButton delete;
    private ImageButton back;
    private DataHelper dataHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_makan_admin);

        // Initialize DataHelper
        dataHelper = new DataHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        menuList = new ArrayList<>();
        menuAdapter = new MenuAdapter(menuList);
        tambah = findViewById(R.id.imageButtonTambah);
        back = findViewById(R.id.imageButton);
        update = findViewById(R.id.imageButton7);
        delete = findViewById(R.id.imageButton8);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // Kembali ke
            }
        });

        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tambah = new Intent(ListMenuMakanAdmin.this, PageTambahMenuMakananAdmin.class);
                startActivityForResult(tambah, 1);
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedItemPosition = menuAdapter.getSelectedItemPosition();

                if (selectedItemPosition != RecyclerView.NO_POSITION) {
                    Menu selectedMenu = menuList.get(selectedItemPosition);
                    Intent editIntent = new Intent(ListMenuMakanAdmin.this, PageEditMenuMakananAdmin.class);
                    editIntent.putExtra("menu", selectedMenu);
                    editIntent.putExtra("position", selectedItemPosition);
                    startActivityForResult(editIntent, 2);
                } else {
                    Log.d("ListMenuMakanAdmin", "No item selected for update");
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedItemPosition = menuAdapter.getSelectedItemPosition();

                if (selectedItemPosition != RecyclerView.NO_POSITION) {
                    Menu selectedMenu = menuList.get(selectedItemPosition);
                    Intent deleteIntent = new Intent(ListMenuMakanAdmin.this, PageDeleteMakananAdmin.class);
                    deleteIntent.putExtra("menu", selectedMenu);
                    startActivityForResult(deleteIntent, 3);
                } else {
                    Log.d("ListMenuMakanAdmin", "No item selected for delete");
                }
            }
        });

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(menuAdapter);

        menuList.clear();
        menuList.addAll(dataHelper.getAllMenu());
        menuAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("menu")) {
                Menu menu = data.getParcelableExtra("menu");
                long result = dataHelper.addMenu(menu);

                if (result != -1) {
                    // Tambahkan item baru ke daftar dan pemberitahuan bahwa item ditambahkan
                    menuList.add(menu);
                    menuAdapter.notifyItemInserted(menuList.size() - 1);
                } else {
                    Log.d("ListMenuMakanAdmin", "Failed to add menu to the database");
                }
            }
        } else if (requestCode == 2 && resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("updatedMenu")) {
                Menu updatedMenu = data.getParcelableExtra("updatedMenu");
                int position = data.getIntExtra("position", -1);

                if (position != -1) {
                    int result = dataHelper.updateMenu(updatedMenu);

                    if (result > 0) {
                        // Perbarui item yang sudah ada di daftar dan pemberitahuan bahwa item diperbarui
                        menuList.set(position, updatedMenu);
                        menuAdapter.notifyItemChanged(position);
                    } else {
                        Log.d("ListMenuMakanAdmin", "Failed to update menu in the database");
                    }
                }
            }
        } else if (requestCode == 3 && resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("deletedMenu")) {
                Menu deletedMenu = data.getParcelableExtra("deletedMenu");

                if (deletedMenu != null) {
                    int result = dataHelper.deleteMenu(deletedMenu.getId());

                    if (result > 0) {
                        // Hapus item yang sudah ada dari daftar dan pemberitahuan bahwa item dihapus
                        int removedPosition = menuList.indexOf(deletedMenu);
                        if (removedPosition != -1) {
                            menuList.remove(removedPosition);
                            menuAdapter.notifyItemRemoved(removedPosition);
                        }
                    } else {
                        Log.d("ListMenuMakanAdmin", "Failed to delete menu from the database");
                    }
                }
            }
        }
    }
}
