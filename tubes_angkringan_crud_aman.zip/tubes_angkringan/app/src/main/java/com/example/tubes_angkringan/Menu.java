package com.example.tubes_angkringan;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcel;
import android.os.Parcelable;

public class Menu implements Parcelable {
    private int id;
    private byte[] imageByteArray;
    private String namaMakanan;
    private String keteranganMakanan;
    private double hargaMakanan;
    private String menuName;

    public Menu() {
        // Default constructor needed for Parcelable
    }

    protected Menu(Parcel in) {
        id = in.readInt();
        imageByteArray = in.createByteArray();
        namaMakanan = in.readString();
        keteranganMakanan = in.readString();
        hargaMakanan = in.readDouble();
    }

    public static final Creator<Menu> CREATOR = new Creator<Menu>() {
        @Override
        public Menu createFromParcel(Parcel in) {
            return new Menu(in);
        }

        @Override
        public Menu[] newArray(int size) {
            return new Menu[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte[] getImageByteArray() {
        return imageByteArray;
    }

    public void setImageByteArray(byte[] imageByteArray) {
        this.imageByteArray = imageByteArray;
    }

    public String getNamaMakanan() {
        return namaMakanan;
    }

    public void setNamaMakanan(String namaMakanan) {
        this.namaMakanan = namaMakanan;
    }

    public String getKeteranganMakanan() {
        return keteranganMakanan;
    }

    public void setKeteranganMakanan(String keteranganMakanan) {
        this.keteranganMakanan = keteranganMakanan;
    }

    public double getHargaMakanan() {
        return hargaMakanan;
    }

    public void setHargaMakanan(double hargaMakanan) {
        this.hargaMakanan = hargaMakanan;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeByteArray(imageByteArray);
        dest.writeString(namaMakanan);
        dest.writeString(keteranganMakanan);
        dest.writeDouble(hargaMakanan);
    }

    public Bitmap getImageBitmap() {
        // Mengonversi byte array ke Bitmap
        if (imageByteArray != null) {
            return BitmapFactory.decodeByteArray(imageByteArray, 0, imageByteArray.length);
        } else {
            return null; // atau Anda dapat mengembalikan gambar placeholder di sini jika tidak ada gambar
        }
    }

        public String getMenuName() {
            return menuName;
        }

}

