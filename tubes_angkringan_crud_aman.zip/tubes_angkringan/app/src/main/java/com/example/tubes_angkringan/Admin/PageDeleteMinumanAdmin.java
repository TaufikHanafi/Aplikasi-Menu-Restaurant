package com.example.tubes_angkringan.Admin;

public class PageDeleteMinumanAdmin {
}
