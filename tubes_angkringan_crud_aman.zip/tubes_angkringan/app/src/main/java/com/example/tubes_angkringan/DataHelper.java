package com.example.tubes_angkringan;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.example.tubes_angkringan.Menu;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class DataHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "menu_db";
    private static final int DATABASE_VERSION = 1;

    // Nama tabel dan kolom-kolomnya
    private static final String TABLE_MENU = "menu";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_IMAGE = "image";
    private static final String COLUMN_NAMA_MAKANAN = "nama_makanan";
    private static final String COLUMN_KETERANGAN_MAKANAN = "keterangan_makanan";
    private static final String COLUMN_HARGA_MAKANAN = "harga_makanan";

    private static final String CREATE_TABLE_MENU =
            "CREATE TABLE " + TABLE_MENU + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_IMAGE + " BLOB," +
                    COLUMN_NAMA_MAKANAN + " TEXT," +
                    COLUMN_KETERANGAN_MAKANAN + " TEXT," +
                    COLUMN_HARGA_MAKANAN + " REAL" +
                    ")";

    public DataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE_MENU);
        } catch (SQLException e) {
            Log.e("DataHelper", "Error creating tables", e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Upgrade database jika versi berbeda
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MENU);
        onCreate(db);
    }

    // Menambahkan menu ke database
    public long addMenu(Menu menu) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_IMAGE, getByteArrayFromBitmap(menu.getImageBitmap()));
        values.put(COLUMN_NAMA_MAKANAN, menu.getNamaMakanan());
        values.put(COLUMN_KETERANGAN_MAKANAN, menu.getKeteranganMakanan());
        values.put(COLUMN_HARGA_MAKANAN, menu.getHargaMakanan());

        long result = db.insert(TABLE_MENU, null, values);
        db.close();

        return result;
    }


    // Mendapatkan semua menu dari database
    @SuppressLint("Range")
    public List<Menu> getAllMenu() {
        List<Menu> menuList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_MENU;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Menu menu = new Menu();
                menu.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));

                // Check if the value is not null before accessing it
                byte[] imageByteArray = cursor.getBlob(cursor.getColumnIndex(COLUMN_IMAGE));
                if (imageByteArray != null) {
                    menu.setImageByteArray(imageByteArray);
                }

                String namaMakanan = cursor.getString(cursor.getColumnIndex(COLUMN_NAMA_MAKANAN));
                if (namaMakanan != null) {
                    menu.setNamaMakanan(namaMakanan);
                }

                String keteranganMakanan = cursor.getString(cursor.getColumnIndex(COLUMN_KETERANGAN_MAKANAN));
                if (keteranganMakanan != null) {
                    menu.setKeteranganMakanan(keteranganMakanan);
                }

                double hargaMakanan = cursor.getDouble(cursor.getColumnIndex(COLUMN_HARGA_MAKANAN));
                // You can choose whether to set the value to 0 or handle it differently if it's null
                menu.setHargaMakanan(hargaMakanan);

                menuList.add(menu);
            } while (cursor.moveToNext());
        }


        cursor.close();
        db.close();
        return menuList;
    }

    // Mengupdate menu di database
    public int updateMenu(Menu menu) {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN_IMAGE, getByteArrayFromBitmap(menu.getImageBitmap()));
            values.put(COLUMN_NAMA_MAKANAN, menu.getNamaMakanan());
            values.put(COLUMN_KETERANGAN_MAKANAN, menu.getKeteranganMakanan());
            values.put(COLUMN_HARGA_MAKANAN, menu.getHargaMakanan());

            return db.update(TABLE_MENU, values, COLUMN_ID + " = ?", new String[]{String.valueOf(menu.getId())});
        } catch (SQLException e) {
            Log.e("DataHelper", "Error updating menu with ID: " + menu.getId(), e);
            return -1; // Menandakan bahwa ada kesalahan
        } finally {
            db.close();
        }
    }


    // Menghapus menu dari database
    public int deleteMenu(int menuId) {
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            return db.delete(TABLE_MENU, COLUMN_ID + " = ?", new String[]{String.valueOf(menuId)});
        } catch (SQLException e) {
            Log.e("DataHelper", "Error deleting menu with ID: " + menuId, e);
            return -1; // Menandakan bahwa ada kesalahan
        } finally {
            db.close();
        }
    }


    // Mengonversi byte array ke Bitmap
    private Bitmap getBitmapFromByteArray(byte[] byteArray) {
        if (byteArray != null) {
            return BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        } else {
            return null; // atau Anda dapat mengembalikan gambar placeholder di sini jika tidak ada gambar
        }
    }

    // Mengonversi Bitmap ke byte array
    private byte[] getByteArrayFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }
}
