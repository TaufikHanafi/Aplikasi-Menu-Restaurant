package com.example.tubes_angkringan.User;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tubes_angkringan.R;

public class DaftarMenuPelanggan extends AppCompatActivity {

    private TextView tvpelanggan;
    private ImageButton kembali;

    private ImageButton makanan;
    private ImageButton minuman;
    private ImageButton cemilan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_menu_pelanggan);

        kembali = findViewById(R.id.imageButtonmenujualan);
        tvpelanggan = findViewById(R.id.tvWelcomePelangganMessage);
        makanan = findViewById(R.id.imageButton23);
        minuman = findViewById(R.id.imageButton24);
        cemilan = findViewById(R.id.imageButton25);

        Intent intent = getIntent();
        if (intent.hasExtra("customerName")){
            String customername = intent.getStringExtra("customerName");
            tvpelanggan.setText("Haloo " + customername + "!!");
        }

        kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish(); // Kembali ke Page1Activity
            }
        });

        makanan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Pindah ke PageButton1Activity
                Intent intent = new Intent(DaftarMenuPelanggan.this, PageMakananPelanggan.class);
                startActivity(intent);
            }
        });

        minuman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Pindah ke PageButton2Activity
                Intent intent = new Intent(DaftarMenuPelanggan.this, PageMinumanPelanggan.class);
                startActivity(intent);
            }
        });

        cemilan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Pindah ke PageButton3Activity
                Intent intent = new Intent(DaftarMenuPelanggan.this, PageCemilanPelanggan.class);
                startActivity(intent);
            }
        });

        // Tambahan kode lainnya untuk Page2Activity jika diperlukan
    }
}

