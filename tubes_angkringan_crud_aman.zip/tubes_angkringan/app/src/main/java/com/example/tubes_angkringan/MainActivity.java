package com.example.tubes_angkringan;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.tubes_angkringan.Admin.PageLoginAdmin;
import com.example.tubes_angkringan.User.DaftarMenuPelanggan;

public class MainActivity extends AppCompatActivity {

    private EditText etInputName;
    private ImageButton imageButton2;
    private ImageButton admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etInputName = findViewById(R.id.etInputName);
        imageButton2 = findViewById(R.id.imageButton2);
        admin = findViewById(R.id.imageButton3);

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String customerName = etInputName.getText().toString();

                Intent intent = new Intent(MainActivity.this, DaftarMenuPelanggan.class);
                intent.putExtra("customerName", customerName);
                startActivity(intent);
            }
        });

        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, PageLoginAdmin.class);
                startActivity(intent);
            }
        });

    }
}
